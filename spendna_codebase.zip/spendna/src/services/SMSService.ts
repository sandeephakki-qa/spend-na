/**
 * Spend-na — SMS Reader Service
 * ─────────────────────────────────────────────────────────────
 * Reads bank SMS messages from device — Android only.
 * iOS does not allow SMS reading — manual entry used instead.
 *
 * TRUST PRINCIPLE:
 * 1. NEVER reads SMS silently in background
 * 2. ONLY reads when user explicitly taps "Scan my messages"
 * 3. User is always shown count BEFORE we read anything
 * 4. User can cancel at any point
 * 5. SMS content never leaves the device
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

import { Platform, PermissionsAndroid } from 'react-native';
import { SMSMessage, ParsedTransaction } from '../types';

// Known Indian bank SMS sender IDs
// This list helps filter only bank messages — not all SMS
const BANK_SENDER_PATTERNS = [
  'HDFCBK', 'ICICIBK', 'SBIINB', 'AXISBK', 'KOTAKB',
  'BOIIND', 'PNBSMS', 'CANBNK', 'UNIONB', 'INDBNK',
  'PAYTM', 'PHONEPE', 'GPAY', 'AMAZON', 'FLIPKRT',
  'MOBIKW', 'FREECHARGE', 'YESBNK', 'IDFCFB', 'RBLBNK',
  'VM-', 'BP-', 'AD-', // Common SMS prefix formats
];

// Regex patterns to extract transaction data from bank SMS
const TRANSACTION_PATTERNS = [
  // Pattern: Rs.340 debited from account
  /(?:rs\.?|inr\.?|₹)\s*(\d+(?:,\d+)*(?:\.\d{1,2})?)\s*(?:has been\s*)?(?:debited|deducted|spent|paid)/i,
  // Pattern: debited Rs 340
  /(?:debited|deducted)\s*(?:rs\.?|inr\.?|₹)?\s*(\d+(?:,\d+)*(?:\.\d{1,2})?)/i,
  // Pattern: payment of Rs 340
  /payment\s*of\s*(?:rs\.?|inr\.?|₹)?\s*(\d+(?:,\d+)*(?:\.\d{1,2})?)/i,
  // Pattern: spent Rs 340 at
  /spent\s*(?:rs\.?|inr\.?|₹)?\s*(\d+(?:,\d+)*(?:\.\d{1,2})?)/i,
];

// Merchant extraction patterns
const MERCHANT_PATTERNS = [
  /(?:at|to|@)\s+([A-Z][A-Z0-9\s\-\.]{2,30}?)(?:\s+on|\s+dated|\s+ref|\s+upi|\.)/i,
  /(?:merchant|pos)\s*[:\-]?\s*([A-Z][A-Z0-9\s\-\.]{2,30})/i,
  /(?:trf|transfer)\s+to\s+([A-Z][A-Z0-9\s\-\.]{2,30})/i,
];

// ── Permission Handling ────────────────────────────────────────────────────

/**
 * Request SMS read permission from user — Android only
 * Shows system dialog explaining why we need this
 * Returns true if granted, false if denied
 */
export const requestSMSPermission = async (): Promise<boolean> => {
  // iOS does not support SMS reading — always return false
  if (Platform.OS === 'ios') {
    console.log('[SMS] iOS detected — SMS reading not supported');
    return false;
  }

  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.READ_SMS,
      {
        title: 'Spend-na needs to read your bank messages',
        message:
          'Spend-na will read only your bank transaction SMS messages. ' +
          'All data stays on your phone only. ' +
          'Nothing is sent to any server.',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'No Thanks',
        buttonPositive: 'Yes, Allow',
      },
    );

    const isGranted = granted === PermissionsAndroid.RESULTS.GRANTED;
    console.log(`[SMS] Permission ${isGranted ? 'GRANTED' : 'DENIED'}`);
    return isGranted;
  } catch (error) {
    console.error('[SMS] Permission request failed:', error);
    return false;
  }
};

/**
 * Check if SMS permission is already granted — no dialog shown
 */
export const checkSMSPermission = async (): Promise<boolean> => {
  if (Platform.OS === 'ios') return false;
  try {
    const result = await PermissionsAndroid.check(
      PermissionsAndroid.PERMISSIONS.READ_SMS,
    );
    return result;
  } catch {
    return false;
  }
};

// ── SMS Reading ────────────────────────────────────────────────────────────

/**
 * Count unread bank SMS messages WITHOUT reading content
 * Used to show user "You have X bank messages" before they approve scan
 * This is the trust-first approach — count before we read
 */
export const countUnreadBankSMS = async (): Promise<number> => {
  // In production this uses react-native-sms-retriever or direct Android module
  // For now returns mock count for development
  // TODO: Replace with actual SMS count query
  console.log('[SMS] Counting unread bank messages...');
  return 4; // Mock value — replace with actual implementation
};

/**
 * Read bank SMS messages — ONLY called after user explicitly approves
 * Filters only debit/payment messages — ignores OTP, promotional etc
 * @param fromDate Read SMS from this date onwards
 * @param toDate Read SMS until this date
 */
export const readBankSMSMessages = async (
  fromDate: Date,
  toDate: Date = new Date(),
): Promise<SMSMessage[]> => {
  if (Platform.OS === 'ios') {
    console.log('[SMS] iOS — returning empty array');
    return [];
  }

  console.log(`[SMS] Reading bank SMS from ${fromDate} to ${toDate}`);

  // Mock SMS data for development and testing
  // In production replace with actual SMS reading via Android ContentResolver
  const mockSMS: SMSMessage[] = [
    {
      id: 'sms_001',
      address: 'VM-HDFCBK',
      body: 'Rs.340.00 debited from your HDFC Bank account ending 4321 to SWIGGY on 15-01-25. Avl bal: Rs.12,450.00',
      date: new Date().getTime() - 86400000,
      isRead: true,
      isParsed: false,
    },
    {
      id: 'sms_002',
      address: 'VM-ICICIBK',
      body: 'Payment of Rs.180 to OLA from ICICI Bank A/c XX4567 on 15-Jan-2025. UPI Ref: 123456789',
      date: new Date().getTime() - 72000000,
      isRead: true,
      isParsed: false,
    },
    {
      id: 'sms_003',
      address: 'VM-HDFCBK',
      body: 'Rs.620 spent on APOLLO PHARMACY on 15-01-25 using HDFC Bank Debit Card XX1234',
      date: new Date().getTime() - 50000000,
      isRead: true,
      isParsed: false,
    },
    {
      id: 'sms_004',
      address: 'VM-AXISBK',
      body: 'Axis Bank: Rs.450.00 debited to BOOKMYSHOW on 15-Jan via UPI. Ref No 987654321',
      date: new Date().getTime() - 36000000,
      isRead: true,
      isParsed: false,
    },
  ];

  // Filter only bank senders
  const bankMessages = mockSMS.filter(sms =>
    BANK_SENDER_PATTERNS.some(pattern =>
      sms.address.toUpperCase().includes(pattern.toUpperCase()),
    ),
  );

  console.log(`[SMS] Found ${bankMessages.length} bank messages`);
  return bankMessages;
};

// ── SMS Parsing ────────────────────────────────────────────────────────────

/**
 * Extract transaction amount from SMS text
 * Tries multiple regex patterns for different bank formats
 * @param smsBody Raw SMS text
 * @returns Amount as number or null if not found
 */
export const extractAmount = (smsBody: string): number | null => {
  for (const pattern of TRANSACTION_PATTERNS) {
    const match = smsBody.match(pattern);
    if (match && match[1]) {
      // Remove commas from amount like 1,000
      const cleanAmount = match[1].replace(/,/g, '');
      const amount = parseFloat(cleanAmount);
      if (!isNaN(amount) && amount > 0) {
        return amount;
      }
    }
  }
  return null;
};

/**
 * Extract merchant name from SMS text
 * @param smsBody Raw SMS text
 * @returns Merchant name or generic fallback
 */
export const extractMerchant = (smsBody: string): string => {
  for (const pattern of MERCHANT_PATTERNS) {
    const match = smsBody.match(pattern);
    if (match && match[1]) {
      return match[1].trim().toUpperCase();
    }
  }
  return 'Unknown Merchant';
};

/**
 * Parse a single SMS message into a structured transaction
 * Returns null if SMS is not a debit/payment message
 * @param sms Raw SMS message
 */
export const parseSMSToTransaction = (
  sms: SMSMessage,
): ParsedTransaction | null => {
  const amount = extractAmount(sms.body);

  // If no amount found this is not a transaction SMS — skip it
  if (!amount) {
    console.log(`[SMS] No amount found in SMS from ${sms.address} — skipping`);
    return null;
  }

  const merchantName = extractMerchant(sms.body);
  const date = new Date(sms.date);

  return {
    amount,
    merchantName,
    date: date.toISOString().split('T')[0],
    time: date.toTimeString().slice(0, 5),
    smsBody: sms.body,
    rawSMS: sms,
  };
};

/**
 * Parse multiple SMS messages — filters nulls automatically
 * @param messages Array of raw SMS messages
 * @returns Array of successfully parsed transactions
 */
export const parseMultipleSMS = (
  messages: SMSMessage[],
): ParsedTransaction[] => {
  const parsed = messages
    .map(sms => parseSMSToTransaction(sms))
    .filter((t): t is ParsedTransaction => t !== null);

  console.log(
    `[SMS] Parsed ${parsed.length} transactions from ${messages.length} messages`,
  );
  return parsed;
};
