/**
 * Spend-na — Local Storage Service
 * ─────────────────────────────────────────────────────────────
 * ALL data stays on device. Nothing sent to any server.
 * Uses AsyncStorage — React Native's built-in local database.
 * ─────────────────────────────────────────────────────────────
 * TRUST PRINCIPLE: This file is the guardian of user privacy.
 * Every read and write is local only. No network calls here.
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Expense, UserProfile, AppSettings, MonthlySummary } from '../types';

// Storage keys — all prefixed with spendna_ to avoid conflicts
const KEYS = {
  EXPENSES: 'spendna_expenses',
  USER_PROFILE: 'spendna_user_profile',
  APP_SETTINGS: 'spendna_app_settings',
  MONTHLY_SUMMARIES: 'spendna_monthly_summaries',
  LAST_SCAN_DATE: 'spendna_last_scan_date',
} as const;

// ── Generic Helpers ────────────────────────────────────────────────────────

/**
 * Save any data to local storage
 * @param key Storage key
 * @param data Data to save
 */
const save = async <T>(key: string, data: T): Promise<void> => {
  try {
    const json = JSON.stringify(data);
    await AsyncStorage.setItem(key, json);
  } catch (error) {
    console.error(`[Storage] Failed to save ${key}:`, error);
    throw new Error(`Storage save failed for ${key}`);
  }
};

/**
 * Load any data from local storage
 * @param key Storage key
 * @returns Parsed data or null if not found
 */
const load = async <T>(key: string): Promise<T | null> => {
  try {
    const json = await AsyncStorage.getItem(key);
    if (!json) return null;
    return JSON.parse(json) as T;
  } catch (error) {
    console.error(`[Storage] Failed to load ${key}:`, error);
    return null;
  }
};

/**
 * Delete data from local storage
 * @param key Storage key
 */
const remove = async (key: string): Promise<void> => {
  try {
    await AsyncStorage.removeItem(key);
  } catch (error) {
    console.error(`[Storage] Failed to remove ${key}:`, error);
  }
};

// ── Expense Operations ─────────────────────────────────────────────────────

/**
 * Get all expenses stored on device
 */
export const getAllExpenses = async (): Promise<Expense[]> => {
  const expenses = await load<Expense[]>(KEYS.EXPENSES);
  return expenses || [];
};

/**
 * Save a new expense — appends to existing list
 * @param expense New expense to save
 */
export const saveExpense = async (expense: Expense): Promise<void> => {
  const existing = await getAllExpenses();
  // Check for duplicate ID — safety guard
  const isDuplicate = existing.some(e => e.id === expense.id);
  if (isDuplicate) {
    console.warn(`[Storage] Duplicate expense ID detected: ${expense.id}`);
    return;
  }
  const updated = [expense, ...existing]; // Newest first
  await save(KEYS.EXPENSES, updated);
};

/**
 * Update an existing expense — used when user classifies a bucket
 * @param expenseId ID of expense to update
 * @param updates Partial expense fields to update
 */
export const updateExpense = async (
  expenseId: string,
  updates: Partial<Expense>,
): Promise<void> => {
  const existing = await getAllExpenses();
  const index = existing.findIndex(e => e.id === expenseId);
  if (index === -1) {
    console.warn(`[Storage] Expense not found for update: ${expenseId}`);
    return;
  }
  existing[index] = {
    ...existing[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  await save(KEYS.EXPENSES, existing);
};

/**
 * Delete an expense permanently
 * @param expenseId ID of expense to delete
 */
export const deleteExpense = async (expenseId: string): Promise<void> => {
  const existing = await getAllExpenses();
  const filtered = existing.filter(e => e.id !== expenseId);
  await save(KEYS.EXPENSES, filtered);
};

/**
 * Get expenses for a specific month
 * @param year Full year e.g. 2025
 * @param month Month number 1-12
 */
export const getExpensesByMonth = async (
  year: number,
  month: number,
): Promise<Expense[]> => {
  const all = await getAllExpenses();
  return all.filter(expense => {
    const date = new Date(expense.date);
    return (
      date.getFullYear() === year &&
      date.getMonth() + 1 === month
    );
  });
};

/**
 * Get all unclassified expenses — pending bucket selection
 */
export const getUnclassifiedExpenses = async (): Promise<Expense[]> => {
  const all = await getAllExpenses();
  return all.filter(e => e.bucket === null);
};

// ── User Profile Operations ────────────────────────────────────────────────

/**
 * Get user profile
 */
export const getUserProfile = async (): Promise<UserProfile | null> => {
  return load<UserProfile>(KEYS.USER_PROFILE);
};

/**
 * Save or update user profile
 * @param profile User profile data
 */
export const saveUserProfile = async (profile: UserProfile): Promise<void> => {
  await save(KEYS.USER_PROFILE, profile);
};

// ── App Settings Operations ────────────────────────────────────────────────

/**
 * Get app settings
 */
export const getAppSettings = async (): Promise<AppSettings | null> => {
  return load<AppSettings>(KEYS.APP_SETTINGS);
};

/**
 * Save app settings
 * @param settings App settings object
 */
export const saveAppSettings = async (settings: AppSettings): Promise<void> => {
  await save(KEYS.APP_SETTINGS, settings);
};

// ── Summary Operations ─────────────────────────────────────────────────────

/**
 * Calculate and return monthly summary from raw expenses
 * This is computed on device — no server aggregation needed
 * @param year Full year
 * @param month Month 1-12
 */
export const calculateMonthlySummary = async (
  year: number,
  month: number,
): Promise<MonthlySummary> => {
  const expenses = await getExpensesByMonth(year, month);

  const summary: MonthlySummary = {
    year,
    month,
    necessary: 0,
    comfortable: 0,
    luxury: 0,
    total: 0,
    transactionCount: expenses.length,
    unclassifiedCount: 0,
  };

  expenses.forEach(expense => {
    if (!expense.bucket) {
      summary.unclassifiedCount++;
      return;
    }
    summary[expense.bucket] += expense.amount;
    summary.total += expense.amount;
  });

  return summary;
};

/**
 * Get last 6 months summaries for trend chart
 */
export const getLast6MonthsSummaries = async (): Promise<MonthlySummary[]> => {
  const summaries: MonthlySummary[] = [];
  const now = new Date();

  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const summary = await calculateMonthlySummary(
      date.getFullYear(),
      date.getMonth() + 1,
    );
    summaries.push(summary);
  }

  return summaries;
};

// ── Clear All Data — Nuclear option for testing ────────────────────────────

/**
 * WARNING: Clears ALL Spend-na data from device
 * Only used in development/testing. Never expose in production UI.
 */
export const clearAllData = async (): Promise<void> => {
  await AsyncStorage.multiRemove(Object.values(KEYS));
  console.warn('[Storage] ALL Spend-na data cleared');
};
