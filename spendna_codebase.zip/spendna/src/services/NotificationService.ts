/**
 * Spend-na — Notification Service
 * ─────────────────────────────────────────────────────────────
 * Handles morning and evening spending awareness notifications.
 * Speaks like a warm parent friend — never alarming or guilty.
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

import PushNotification from 'react-native-push-notification';
import { Platform } from 'react-native';
import { MonthlySummary } from '../types';

// Notification channel IDs
const CHANNELS = {
  MORNING: 'spendna_morning',
  EVENING: 'spendna_evening',
  REMINDER: 'spendna_reminder',
};

// ── Morning Messages ───────────────────────────────────────────────────────
// Warm, friendly, never preachy
const MORNING_MESSAGES = [
  "Good morning! Yesterday's picture is ready. Come take a look 🌅",
  "Rise and shine! See where yesterday's money flew 🐦",
  "Good morning! Your spending story from yesterday is waiting 🌿",
  "A new day, a fresh start. Peek at yesterday's buckets ☀️",
  "Morning! Yesterday is done. Let us see what the picture looks like 🎨",
];

// ── Evening Messages ───────────────────────────────────────────────────────
// Gentle check-in tone — day not over yet
const EVENING_MESSAGES_GOOD = [
  "Evening! Today's looking balanced. Want to see? 🌙",
  "The day is winding down. Your buckets have a story to tell 🌆",
  "Good evening! Today was a good day for your wallet 🙂",
];

const EVENING_MESSAGES_WATCH = [
  "Evening check-in! The red bucket had a busy day. Just so you know 🌙",
  "Hey! Today's comfort spending is a little high. Worth a glance 👀",
  "Evening! You still have time to make tonight's choices count 🌆",
];

// ── Unclassified Reminder ─────────────────────────────────────────────────
const UNCLASSIFIED_MESSAGES = (count: number) => [
  `You have ${count} spends waiting to be sorted. Whenever you are ready 📬`,
  `${count} bank messages are patiently waiting. Sort them in 30 seconds 🕐`,
  `Hey! ${count} spends still need your attention. Quick tap and done ✌️`,
];

// ── Helper ─────────────────────────────────────────────────────────────────

/**
 * Get a random message from an array
 * Different message every day keeps it fresh
 */
const randomMessage = (messages: string[]): string => {
  return messages[Math.floor(Math.random() * messages.length)];
};

// ── Setup ──────────────────────────────────────────────────────────────────

/**
 * Configure notification channels — called once on app start
 */
export const setupNotifications = (): void => {
  // Create channels for Android
  PushNotification.createChannel(
    {
      channelId: CHANNELS.MORNING,
      channelName: 'Morning Awareness',
      channelDescription: 'Your daily morning spending recap',
      soundName: 'default',
      importance: 3,
      vibrate: true,
    },
    created => console.log(`[Notifications] Morning channel created: ${created}`),
  );

  PushNotification.createChannel(
    {
      channelId: CHANNELS.EVENING,
      channelName: 'Evening Check-in',
      channelDescription: 'Your gentle evening spending summary',
      soundName: 'default',
      importance: 3,
      vibrate: false, // Less intrusive in evening
    },
    created => console.log(`[Notifications] Evening channel created: ${created}`),
  );

  PushNotification.createChannel(
    {
      channelId: CHANNELS.REMINDER,
      channelName: 'Reminders',
      channelDescription: 'Gentle reminders about unclassified spends',
      soundName: 'default',
      importance: 2,
      vibrate: false,
    },
    () => {},
  );

  console.log('[Notifications] All channels configured');
};

// ── Schedule Notifications ─────────────────────────────────────────────────

/**
 * Schedule daily morning notification
 * Shows yesterday's spending recap
 * @param hour Hour in 24h format — default 8 (8 AM)
 * @param minute Minute — default 0
 */
export const scheduleMorningNotification = (
  hour: number = 8,
  minute: number = 0,
): void => {
  // Cancel any existing morning notifications first
  PushNotification.cancelLocalNotification('morning_daily');

  const now = new Date();
  const scheduledTime = new Date();
  scheduledTime.setHours(hour, minute, 0, 0);

  // If time has passed today schedule for tomorrow
  if (scheduledTime <= now) {
    scheduledTime.setDate(scheduledTime.getDate() + 1);
  }

  PushNotification.localNotificationSchedule({
    id: 'morning_daily',
    channelId: CHANNELS.MORNING,
    title: 'Spend-na 🐦',
    message: randomMessage(MORNING_MESSAGES),
    date: scheduledTime,
    repeatType: 'day',
    allowWhileIdle: true,
    importance: 'high',
    vibrate: true,
    playSound: true,
  });

  console.log(`[Notifications] Morning notification scheduled for ${hour}:${minute}`);
};

/**
 * Schedule daily evening notification
 * Shows today's spending summary with warm tone
 * @param summary Today's spending summary to personalise message
 * @param hour Hour — default 21 (9 PM)
 * @param minute Minute — default 0
 */
export const scheduleEveningNotification = (
  summary: MonthlySummary | null,
  hour: number = 21,
  minute: number = 0,
): void => {
  PushNotification.cancelLocalNotification('evening_daily');

  const scheduledTime = new Date();
  scheduledTime.setHours(hour, minute, 0, 0);

  const now = new Date();
  if (scheduledTime <= now) {
    scheduledTime.setDate(scheduledTime.getDate() + 1);
  }

  // Choose message tone based on luxury spending
  let messages = EVENING_MESSAGES_GOOD;
  if (summary && summary.luxury > summary.comfortable) {
    messages = EVENING_MESSAGES_WATCH;
  }

  PushNotification.localNotificationSchedule({
    id: 'evening_daily',
    channelId: CHANNELS.EVENING,
    title: 'Spend-na 🌙',
    message: randomMessage(messages),
    date: scheduledTime,
    repeatType: 'day',
    allowWhileIdle: true,
    importance: 'default',
    vibrate: false,
    playSound: false, // Silent in evening — less intrusive
  });

  console.log(`[Notifications] Evening notification scheduled for ${hour}:${minute}`);
};

/**
 * Send immediate reminder about unclassified transactions
 * Only sent if user has 3 or more unclassified spends
 * @param count Number of unclassified transactions
 */
export const sendUnclassifiedReminder = (count: number): void => {
  if (count < 3) return; // Do not nag for small numbers

  const messages = UNCLASSIFIED_MESSAGES(count);

  PushNotification.localNotification({
    channelId: CHANNELS.REMINDER,
    title: 'Spend-na 📬',
    message: randomMessage(messages),
    importance: 'low',
    vibrate: false,
    playSound: false,
  });

  console.log(`[Notifications] Unclassified reminder sent for ${count} items`);
};

/**
 * Cancel all scheduled Spend-na notifications
 * Called when user disables notifications in settings
 */
export const cancelAllNotifications = (): void => {
  PushNotification.cancelAllLocalNotifications();
  console.log('[Notifications] All notifications cancelled');
};
