/**
 * Spend-na — Home Screen
 * ─────────────────────────────────────────────────────────────
 * The wallet moment. First thing user sees every morning.
 * Warm greeting, weather feel, personal photo, motivational
 * quote, pending spends nudge, quick monthly summary.
 *
 * Design principle: Open a wallet. See something personal.
 * Then look at your money. Never the other way around.
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  StatusBar,
  RefreshControl,
  Dimensions,
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { Colors, BucketConfig } from '../theme/colors';
import { Typography, Spacing } from '../theme/typography';
import {
  getUserProfile,
  getUnclassifiedExpenses,
  calculateMonthlySummary,
} from '../services/StorageService';
import { UserProfile, MonthlySummary } from '../types';

const { width } = Dimensions.get('window');

// ── Greeting Logic ─────────────────────────────────────────────────────────

const getGreeting = (): string => {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  return 'Good Evening';
};

const getWeatherEmoji = (): string => {
  // In future connect to weather API
  // For now returns a pleasant default
  const hour = new Date().getHours();
  if (hour < 6) return '🌙';
  if (hour < 8) return '🌅';
  if (hour < 17) return '⛅';
  return '🌆';
};

const formatDate = (): string => {
  return new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
};

// ── Motivational Lines ─────────────────────────────────────────────────────
// Warm parent friend tone. Rotate daily.
const DAILY_LINES = [
  'Every rupee has a story. Make yours count today 🌱',
  'Small awareness today. Big freedom tomorrow 🕊️',
  'Your future self will thank you for today\'s choices 💫',
  'Money feels better when you know where it goes 🎯',
  'Awareness is the first step. You are already ahead 🌟',
  'Not about saving every rupee. About knowing every rupee 🤝',
  'The best investment? Understanding yourself 💡',
];

const getDailyLine = (): string => {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000,
  );
  return DAILY_LINES[dayOfYear % DAILY_LINES.length];
};

// ── Component ──────────────────────────────────────────────────────────────

const HomeScreen: React.FC = () => {
  const navigation = useNavigation<any>();

  // State
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [unclassifiedCount, setUnclassifiedCount] = useState(0);
  const [summary, setSummary] = useState<MonthlySummary | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Load all data
  const loadData = useCallback(async () => {
    try {
      const now = new Date();
      const [userProfile, unclassified, monthlySummary] = await Promise.all([
        getUserProfile(),
        getUnclassifiedExpenses(),
        calculateMonthlySummary(now.getFullYear(), now.getMonth() + 1),
      ]);

      setProfile(userProfile);
      setUnclassifiedCount(unclassified.length);
      setSummary(monthlySummary);
    } catch (error) {
      console.error('[HomeScreen] Failed to load data:', error);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  // Reload data every time screen comes into focus
  // So pie updates after user classifies a transaction
  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData]),
  );

  const onRefresh = () => {
    setIsRefreshing(true);
    loadData();
  };

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.backgroundDark} />

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={onRefresh}
            tintColor={Colors.brand}
          />
        }>

        {/* ── Dark Header Section ────────────────────────────────────────── */}
        <View style={styles.header}>

          {/* Greeting Row */}
          <View style={styles.greetingRow}>
            <View>
              <Text style={styles.greetingLabel}>{getGreeting()}</Text>
              <Text style={styles.greetingName}>
                {profile?.displayName || 'Friend'} 👋
              </Text>
              <Text style={styles.dateText}>{formatDate()}</Text>
            </View>
            <View style={styles.weatherContainer}>
              <Text style={styles.weatherEmoji}>{getWeatherEmoji()}</Text>
              <Text style={styles.weatherText}>Bangalore</Text>
            </View>
          </View>

          {/* ── Wallet Card ──────────────────────────────────────────────── */}
          {/* The most personal part of the app */}
          <View style={styles.walletCard}>
            <View style={styles.walletPhotoContainer}>
              {profile?.walletPhotoUri ? (
                <Image
                  source={{ uri: profile.walletPhotoUri }}
                  style={styles.walletPhoto}
                  resizeMode="cover"
                />
              ) : (
                // Default if no photo set — encourage user to personalise
                <View style={styles.walletPhotoPlaceholder}>
                  <Text style={styles.walletPhotoEmoji}>🙏</Text>
                </View>
              )}
            </View>
            <View style={styles.walletTextContainer}>
              <Text style={styles.walletQuoteLabel}>Your daily reminder</Text>
              <Text style={styles.walletQuote} numberOfLines={3}>
                {profile?.walletQuote || getDailyLine()}
              </Text>
            </View>
          </View>

        </View>

        {/* ── Light Content Section ──────────────────────────────────────── */}
        <View style={styles.content}>

          {/* ── Unclassified Spends Nudge ──────────────────────────────── */}
          {/* Show only if there are pending spends — gentle not alarming */}
          {unclassifiedCount > 0 && (
            <TouchableOpacity
              style={styles.nudgeCard}
              onPress={() => navigation.navigate('Sort')}
              activeOpacity={0.85}>
              <Text style={styles.nudgeIcon}>📨</Text>
              <View style={styles.nudgeText}>
                <Text style={styles.nudgeTitle}>
                  {unclassifiedCount} spend{unclassifiedCount > 1 ? 's' : ''} waiting
                </Text>
                <Text style={styles.nudgeSubtitle}>
                  from recent messages — sort when ready
                </Text>
              </View>
              <Text style={styles.nudgeArrow}>›</Text>
            </TouchableOpacity>
          )}

          {/* ── This Month Summary ─────────────────────────────────────── */}
          <View style={styles.summaryCard}>
            <Text style={styles.sectionTitle}>This Month So Far</Text>

            {summary && summary.total > 0 ? (
              <View style={styles.bucketRow}>
                {Object.entries(BucketConfig).map(([key, config]) => {
                  const amount = summary[key as keyof MonthlySummary] as number;
                  return (
                    <TouchableOpacity
                      key={key}
                      style={styles.bucketItem}
                      onPress={() => navigation.navigate('Pie')}
                      activeOpacity={0.8}>
                      <View
                        style={[
                          styles.bucketDot,
                          { backgroundColor: config.color },
                        ]}
                      />
                      <Text style={[styles.bucketAmount, { color: config.color }]}>
                        ₹{amount >= 1000
                          ? `${(amount / 1000).toFixed(1)}k`
                          : amount.toFixed(0)}
                      </Text>
                      <Text style={styles.bucketLabel}>{config.label}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyEmoji}>🌱</Text>
                <Text style={styles.emptyText}>
                  No spends sorted yet this month
                </Text>
              </View>
            )}

            {/* View full picture button */}
            {summary && summary.total > 0 && (
              <TouchableOpacity
                style={styles.viewPictureButton}
                onPress={() => navigation.navigate('Pie')}>
                <Text style={styles.viewPictureText}>See full picture →</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* ── Motivational Footer Line ───────────────────────────────── */}
          <Text style={styles.footerLine}>{getDailyLine()}</Text>

          {/* ── Manual Add Button ──────────────────────────────────────── */}
          <TouchableOpacity
            style={styles.manualAddButton}
            onPress={() => navigation.navigate('ManualAdd')}
            activeOpacity={0.85}>
            <Text style={styles.manualAddIcon}>+</Text>
            <Text style={styles.manualAddText}>Add a spend manually</Text>
            <Text style={styles.manualAddSubtext}>cash · others card · hand loan</Text>
          </TouchableOpacity>

          {/* Bottom padding for scroll */}
          <View style={{ height: 32 }} />
        </View>
      </ScrollView>
    </View>
  );
};

// ── Styles ─────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundDark,
  },

  // Header — dark background
  header: {
    backgroundColor: Colors.backgroundDark,
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.xxl,
  },
  greetingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.base,
  },
  greetingLabel: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: Typography.letterSpacing.wider,
  },
  greetingName: {
    fontSize: Typography.fontSize.xxl,
    fontWeight: Typography.fontWeight.extrabold,
    color: Colors.textWhite,
    marginTop: 2,
  },
  dateText: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  weatherContainer: {
    alignItems: 'flex-end',
  },
  weatherEmoji: {
    fontSize: 28,
  },
  weatherText: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
    marginTop: 2,
  },

  // Wallet Card
  walletCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(34,211,238,0.08)',
    borderRadius: Spacing.radius.xl,
    borderWidth: 1,
    borderColor: 'rgba(34,211,238,0.2)',
    padding: Spacing.base,
    gap: Spacing.md,
    alignItems: 'center',
  },
  walletPhotoContainer: {
    flexShrink: 0,
  },
  walletPhoto: {
    width: 60,
    height: 60,
    borderRadius: Spacing.radius.lg,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  walletPhotoPlaceholder: {
    width: 60,
    height: 60,
    borderRadius: Spacing.radius.lg,
    backgroundColor: 'rgba(245,158,11,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  walletPhotoEmoji: {
    fontSize: 28,
  },
  walletTextContainer: {
    flex: 1,
  },
  walletQuoteLabel: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
    marginBottom: 4,
  },
  walletQuote: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textOnDark,
    lineHeight: Typography.fontSize.sm * 1.6,
    fontStyle: 'italic',
  },

  // Content — light background
  content: {
    backgroundColor: Colors.background,
    borderTopLeftRadius: Spacing.radius.xxl,
    borderTopRightRadius: Spacing.radius.xxl,
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.xl,
    marginTop: -Spacing.xl,
  },

  // Nudge card
  nudgeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff0f3',
    borderRadius: Spacing.radius.lg,
    borderWidth: 1,
    borderColor: `${Colors.luxury}40`,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    gap: Spacing.sm,
  },
  nudgeIcon: {
    fontSize: 22,
  },
  nudgeText: {
    flex: 1,
  },
  nudgeTitle: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.bold,
    color: '#e11d48',
  },
  nudgeSubtitle: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
    marginTop: 1,
  },
  nudgeArrow: {
    fontSize: 22,
    color: '#e11d48',
  },

  // Summary card
  summaryCard: {
    backgroundColor: Colors.card,
    borderRadius: Spacing.radius.xl,
    padding: Spacing.base,
    marginBottom: Spacing.md,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: Typography.letterSpacing.wider,
    marginBottom: Spacing.md,
  },
  bucketRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  bucketItem: {
    alignItems: 'center',
    gap: Spacing.xs,
  },
  bucketDot: {
    width: 44,
    height: 44,
    borderRadius: Spacing.radius.md,
    marginBottom: 2,
  },
  bucketAmount: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.bold,
  },
  bucketLabel: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: Spacing.lg,
  },
  emptyEmoji: {
    fontSize: 32,
    marginBottom: Spacing.sm,
  },
  emptyText: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textMuted,
    textAlign: 'center',
  },
  viewPictureButton: {
    alignItems: 'flex-end',
    marginTop: Spacing.sm,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.divider,
  },
  viewPictureText: {
    fontSize: Typography.fontSize.sm,
    color: Colors.brand,
    fontWeight: Typography.fontWeight.semibold,
  },

  // Footer line
  footerLine: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textMuted,
    textAlign: 'center',
    fontStyle: 'italic',
    marginBottom: Spacing.base,
    paddingHorizontal: Spacing.lg,
    lineHeight: Typography.fontSize.sm * 1.6,
  },

  // Manual add button
  manualAddButton: {
    backgroundColor: Colors.card,
    borderRadius: Spacing.radius.xl,
    padding: Spacing.base,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: `${Colors.brand}40`,
    borderStyle: 'dashed',
    gap: 2,
  },
  manualAddIcon: {
    fontSize: 24,
    color: Colors.brand,
    fontWeight: Typography.fontWeight.bold,
  },
  manualAddText: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.textPrimary,
  },
  manualAddSubtext: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
  },
});

export default HomeScreen;
