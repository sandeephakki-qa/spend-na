/**
 * Spend-na — Sort Screen
 * ─────────────────────────────────────────────────────────────
 * The classification moment. User sorts each transaction
 * into one of three buckets. Simple. Tactile. Empowering.
 *
 * Design principle: The act of classifying IS the awareness.
 * That small tap makes the user think "was this necessary?"
 * We never answer for them. They decide. Always.
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Animated,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Colors, BucketConfig } from '../theme/colors';
import { Typography, Spacing } from '../theme/typography';
import {
  getUnclassifiedExpenses,
  updateExpense,
  saveExpense,
} from '../services/StorageService';
import {
  requestSMSPermission,
  readBankSMSMessages,
  parseMultipleSMS,
} from '../services/SMSService';
import { Expense, BucketKey, ParsedTransaction } from '../types';
import { generateId } from '../utils/helpers';

// ── Transaction Card Component ─────────────────────────────────────────────

interface TransactionCardProps {
  expense: Expense;
  onClassify: (id: string, bucket: BucketKey) => void;
}

const TransactionCard: React.FC<TransactionCardProps> = ({
  expense,
  onClassify,
}) => {
  const scaleAnim = new Animated.Value(1);

  const handleBucketPress = (bucket: BucketKey) => {
    // Satisfying scale animation — tactile feel
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.96,
        duration: 80,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 80,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onClassify(expense.id, bucket);
    });
  };

  const isClassified = expense.bucket !== null;
  const config = isClassified ? BucketConfig[expense.bucket!] : null;

  return (
    <Animated.View style={[styles.card, { transform: [{ scale: scaleAnim }] }]}>

      {/* Card Header — merchant and amount */}
      <View style={styles.cardHeader}>
        <View style={styles.cardLeft}>
          <Text style={styles.merchantName} numberOfLines={1}>
            {expense.merchantName}
          </Text>
          <Text style={styles.cardMeta}>
            {expense.time} · {expense.isManual ? 'Manual entry' : 'via UPI'}
          </Text>
        </View>
        <Text style={styles.amount}>₹{expense.amount.toLocaleString('en-IN')}</Text>
      </View>

      {/* SMS preview — helps user recognise the transaction */}
      {expense.smsBody && (
        <Text style={styles.smsPreview} numberOfLines={2}>
          {expense.smsBody}
        </Text>
      )}

      {/* Bucket selection OR classified confirmation */}
      {!isClassified ? (
        <View style={styles.bucketButtons}>
          {Object.entries(BucketConfig).map(([key, cfg]) => (
            <TouchableOpacity
              key={key}
              style={[styles.bucketButton, { borderColor: cfg.color }]}
              onPress={() => handleBucketPress(key as BucketKey)}
              activeOpacity={0.75}>
              <Text style={styles.bucketButtonIcon}>{cfg.icon}</Text>
              <Text style={[styles.bucketButtonLabel, { color: cfg.color }]}>
                {cfg.shortLabel}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      ) : (
        // Classified confirmation
        <View
          style={[
            styles.classifiedBadge,
            { backgroundColor: `${config!.color}15` },
          ]}>
          <Text style={styles.classifiedIcon}>{config!.icon}</Text>
          <Text style={[styles.classifiedText, { color: config!.color }]}>
            {config!.label}
          </Text>
          <Text style={styles.classifiedTick}>✓</Text>
        </View>
      )}
    </Animated.View>
  );
};

// ── Main Sort Screen ───────────────────────────────────────────────────────

const SortScreen: React.FC = () => {
  const navigation = useNavigation<any>();

  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [allSorted, setAllSorted] = useState(false);

  // Load existing unclassified expenses
  const loadExpenses = useCallback(async () => {
    try {
      const unclassified = await getUnclassifiedExpenses();
      setExpenses(unclassified);
      if (unclassified.length === 0) setAllSorted(true);
    } catch (error) {
      console.error('[SortScreen] Failed to load expenses:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadExpenses();
  }, [loadExpenses]);

  // ── SMS Scan ─────────────────────────────────────────────────────────────

  const handleScanSMS = async () => {
    setIsScanning(true);
    try {
      // Step 1: Request permission with honest explanation
      const hasPermission = await requestSMSPermission();
      if (!hasPermission) {
        Alert.alert(
          'Permission needed',
          'Spend-na needs SMS permission to read your bank messages. ' +
          'All data stays on your phone only.',
          [{ text: 'OK' }],
        );
        return;
      }

      // Step 2: Read bank SMS messages
      const fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - 30); // Last 30 days
      const messages = await readBankSMSMessages(fromDate);

      if (messages.length === 0) {
        Alert.alert(
          'No new messages',
          'No new bank transaction messages found in the last 30 days.',
          [{ text: 'OK' }],
        );
        return;
      }

      // Step 3: Parse SMS to transactions
      const parsed: ParsedTransaction[] = parseMultipleSMS(messages);

      if (parsed.length === 0) {
        Alert.alert(
          'Nothing to sort',
          'Could not extract transaction details from the messages found.',
          [{ text: 'OK' }],
        );
        return;
      }

      // Step 4: Convert to Expense objects and save
      const now = new Date().toISOString();
      const newExpenses: Expense[] = parsed.map(t => ({
        id: generateId(),
        amount: t.amount,
        merchantName: t.merchantName,
        bucket: null, // Not classified yet
        paymentSource: 'sms',
        date: t.date,
        time: t.time,
        smsBody: t.smsBody,
        isManual: false,
        isAISuggested: false,
        createdAt: now,
        updatedAt: now,
      }));

      // Save each new expense
      for (const expense of newExpenses) {
        await saveExpense(expense);
      }

      // Reload the list
      await loadExpenses();

    } catch (error) {
      console.error('[SortScreen] SMS scan failed:', error);
      Alert.alert('Something went wrong', 'Please try scanning again.');
    } finally {
      setIsScanning(false);
    }
  };

  // ── Classify ──────────────────────────────────────────────────────────────

  const handleClassify = useCallback(
    async (expenseId: string, bucket: BucketKey) => {
      try {
        // Update in storage
        await updateExpense(expenseId, { bucket });

        // Update local state immediately — no reload needed
        const updated = expenses.map(e =>
          e.id === expenseId ? { ...e, bucket } : e,
        );
        setExpenses(updated);

        // Check if all are now classified
        const stillUnclassified = updated.filter(e => e.bucket === null);
        if (stillUnclassified.length === 0) {
          // Small delay for last animation to complete
          setTimeout(() => setAllSorted(true), 400);
        }
      } catch (error) {
        console.error('[SortScreen] Classify failed:', error);
      }
    },
    [expenses],
  );

  // ── All Sorted Celebration ─────────────────────────────────────────────

  if (allSorted && expenses.length > 0) {
    return (
      <View style={styles.celebrationContainer}>
        <Text style={styles.celebrationEmoji}>🕊️</Text>
        <Text style={styles.celebrationTitle}>All sorted!</Text>
        <Text style={styles.celebrationSubtitle}>
          Your picture for today is ready.{'\n'}
          Come see where your money flew.
        </Text>
        <TouchableOpacity
          style={styles.celebrationButton}
          onPress={() => navigation.navigate('Pie')}>
          <Text style={styles.celebrationButtonText}>See my picture →</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ── Empty State ────────────────────────────────────────────────────────

  if (!isLoading && expenses.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyEmoji}>📭</Text>
        <Text style={styles.emptyTitle}>Nothing waiting</Text>
        <Text style={styles.emptySubtitle}>
          Scan your bank messages or add a spend manually
        </Text>
        <TouchableOpacity
          style={styles.scanButton}
          onPress={handleScanSMS}
          disabled={isScanning}>
          {isScanning ? (
            <ActivityIndicator color={Colors.textWhite} />
          ) : (
            <Text style={styles.scanButtonText}>📱 Scan bank messages</Text>
          )}
        </TouchableOpacity>
      </View>
    );
  }

  // ── Main List ──────────────────────────────────────────────────────────

  const unclassifiedCount = expenses.filter(e => e.bucket === null).length;

  return (
    <View style={styles.container}>

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Sort your spends</Text>
          <Text style={styles.headerSubtitle}>
            {unclassifiedCount} of {expenses.length} remaining — take your time
          </Text>
        </View>
        <TouchableOpacity
          style={styles.scanSmallButton}
          onPress={handleScanSMS}
          disabled={isScanning}>
          {isScanning ? (
            <ActivityIndicator size="small" color={Colors.brand} />
          ) : (
            <Text style={styles.scanSmallText}>📱 Scan</Text>
          )}
        </TouchableOpacity>
      </View>

      {/* Transaction Cards */}
      {isLoading ? (
        <ActivityIndicator
          style={{ marginTop: 60 }}
          size="large"
          color={Colors.brand}
        />
      ) : (
        <FlatList
          data={expenses}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <TransactionCard expense={item} onClassify={handleClassify} />
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

// ── Styles ─────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingTop: Spacing.base,
    paddingBottom: Spacing.md,
    backgroundColor: Colors.card,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    fontSize: Typography.fontSize.lg,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.textPrimary,
  },
  headerSubtitle: {
    fontSize: Typography.fontSize.sm,
    color: Colors.textMuted,
    marginTop: 2,
  },
  scanSmallButton: {
    backgroundColor: `${Colors.brand}15`,
    borderRadius: Spacing.radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
    borderColor: `${Colors.brand}40`,
  },
  scanSmallText: {
    fontSize: Typography.fontSize.sm,
    color: Colors.brand,
    fontWeight: Typography.fontWeight.semibold,
  },
  listContent: {
    padding: Spacing.md,
    gap: Spacing.sm,
  },

  // Transaction Card
  card: {
    backgroundColor: Colors.card,
    borderRadius: Spacing.radius.lg,
    padding: Spacing.base,
    borderWidth: 1.5,
    borderColor: Colors.border,
    marginBottom: Spacing.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.sm,
  },
  cardLeft: {
    flex: 1,
    marginRight: Spacing.sm,
  },
  merchantName: {
    fontSize: Typography.fontSize.md,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.textPrimary,
  },
  cardMeta: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
    marginTop: 2,
  },
  amount: {
    fontSize: Typography.fontSize.lg,
    fontWeight: Typography.fontWeight.extrabold,
    color: Colors.textPrimary,
  },
  smsPreview: {
    fontSize: Typography.fontSize.xs,
    color: Colors.textMuted,
    backgroundColor: Colors.background,
    borderRadius: Spacing.radius.sm,
    padding: Spacing.sm,
    marginBottom: Spacing.sm,
    fontFamily: Typography.fontFamily.mono,
    lineHeight: Typography.fontSize.xs * 1.6,
  },

  // Bucket Buttons
  bucketButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  bucketButton: {
    flex: 1,
    backgroundColor: Colors.background,
    borderWidth: 1.5,
    borderRadius: Spacing.radius.md,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.xs,
    alignItems: 'center',
    gap: 2,
  },
  bucketButtonIcon: {
    fontSize: 20,
  },
  bucketButtonLabel: {
    fontSize: Typography.fontSize.xs,
    fontWeight: Typography.fontWeight.bold,
  },

  // Classified Badge
  classifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: Spacing.radius.md,
    paddingVertical: Spacing.sm,
    gap: Spacing.xs,
  },
  classifiedIcon: {
    fontSize: 16,
  },
  classifiedText: {
    fontSize: Typography.fontSize.sm,
    fontWeight: Typography.fontWeight.bold,
  },
  classifiedTick: {
    fontSize: Typography.fontSize.sm,
    color: Colors.success,
    fontWeight: Typography.fontWeight.bold,
  },

  // All Sorted Celebration
  celebrationContainer: {
    flex: 1,
    backgroundColor: Colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xxl,
  },
  celebrationEmoji: {
    fontSize: 64,
    marginBottom: Spacing.base,
  },
  celebrationTitle: {
    fontSize: Typography.fontSize.xxxl,
    fontWeight: Typography.fontWeight.extrabold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  celebrationSubtitle: {
    fontSize: Typography.fontSize.md,
    color: Colors.textMuted,
    textAlign: 'center',
    lineHeight: Typography.fontSize.md * 1.6,
    marginBottom: Spacing.xxl,
  },
  celebrationButton: {
    backgroundColor: Colors.brand,
    borderRadius: Spacing.radius.lg,
    paddingHorizontal: Spacing.xxl,
    paddingVertical: Spacing.base,
  },
  celebrationButtonText: {
    fontSize: Typography.fontSize.md,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.textWhite,
  },

  // Empty State
  emptyContainer: {
    flex: 1,
    backgroundColor: Colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xxl,
  },
  emptyEmoji: {
    fontSize: 48,
    marginBottom: Spacing.base,
  },
  emptyTitle: {
    fontSize: Typography.fontSize.xl,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  emptySubtitle: {
    fontSize: Typography.fontSize.base,
    color: Colors.textMuted,
    textAlign: 'center',
    marginBottom: Spacing.xxl,
    lineHeight: Typography.fontSize.base * 1.6,
  },
  scanButton: {
    backgroundColor: Colors.brand,
    borderRadius: Spacing.radius.lg,
    paddingHorizontal: Spacing.xxl,
    paddingVertical: Spacing.base,
    minWidth: 200,
    alignItems: 'center',
  },
  scanButtonText: {
    fontSize: Typography.fontSize.base,
    fontWeight: Typography.fontWeight.bold,
    color: Colors.textWhite,
  },
});

export default SortScreen;
