/**
 * Spend-na — Core Types & Models
 * ─────────────────────────────────────────────────────────────
 * Single source of truth for all data structures.
 * Change a model here → TypeScript catches all affected files.
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

// ── Bucket Types ───────────────────────────────────────────────────────────
export type BucketKey = 'necessary' | 'comfortable' | 'luxury';

export const BucketValue = {
  necessary: 0,
  comfortable: 1,
  luxury: 2,
} as const;

// ── Payment Source ─────────────────────────────────────────────────────────
export type PaymentSource =
  | 'upi'        // UPI payment
  | 'card'       // Debit or credit card
  | 'cash'       // Physical cash
  | 'others'     // Someone else's card or UPI
  | 'hand_loan'  // Borrowed from someone
  | 'sms';       // Auto-read from SMS

// ── Expense Model ──────────────────────────────────────────────────────────
export interface Expense {
  id: string;                    // Unique ID — UUID generated locally
  amount: number;                // Amount in rupees
  merchantName: string;          // Where money was spent
  bucket: BucketKey | null;      // null = not yet classified
  paymentSource: PaymentSource;  // How it was paid
  date: string;                  // ISO date string
  time: string;                  // HH:MM format
  note?: string;                 // Optional user note
  smsBody?: string;              // Original SMS if auto-read
  isManual: boolean;             // true = user added manually
  isAISuggested: boolean;        // true = app suggested the bucket
  wasItWorthIt?: boolean;        // User reflection — yes or no
  createdAt: string;             // When record was created
  updatedAt: string;             // Last modification time
}

// ── SMS Message Model ──────────────────────────────────────────────────────
export interface SMSMessage {
  id: string;         // SMS ID from device
  address: string;    // Sender — bank short code like VM-HDFCBK
  body: string;       // Full SMS text
  date: number;       // Timestamp in ms
  isRead: boolean;    // Was SMS already read by user
  isParsed: boolean;  // Did we extract transaction data
}

// ── Parsed Transaction from SMS ───────────────────────────────────────────
export interface ParsedTransaction {
  amount: number;
  merchantName: string;
  date: string;
  time: string;
  smsBody: string;
  rawSMS: SMSMessage;
}

// ── Monthly Summary ────────────────────────────────────────────────────────
export interface MonthlySummary {
  year: number;
  month: number;                  // 1-12
  necessary: number;              // Total in rupees
  comfortable: number;
  luxury: number;
  total: number;
  transactionCount: number;
  unclassifiedCount: number;      // Still pending bucket selection
}

// ── Bucket Summary for Dashboard ──────────────────────────────────────────
export interface BucketSummary {
  key: BucketKey;
  label: string;
  amount: number;
  percentage: number;
  count: number;
  color: string;
}

// ── User Profile ───────────────────────────────────────────────────────────
export interface UserProfile {
  id: string;
  displayName: string;
  walletPhotoUri?: string;        // Personal photo shown on home screen
  walletQuote?: string;           // Personal motivational quote
  monthlyBudget?: {
    necessary?: number;
    comfortable?: number;
    luxury?: number;
  };
  notificationsEnabled: boolean;
  morningNotificationTime: string; // HH:MM — default 08:00
  eveningNotificationTime: string; // HH:MM — default 09:00 PM
  learningPhaseComplete: boolean;  // True after 3 months — then nudges start
  createdAt: string;
  totalMonthsTracked: number;
}

// ── App Settings ───────────────────────────────────────────────────────────
export interface AppSettings {
  themeMode: 'light' | 'dark' | 'system';
  currency: string;               // INR by default
  language: string;               // en by default
  smsPermissionGranted: boolean;
  notificationPermissionGranted: boolean;
  onboardingComplete: boolean;
  lastSMSScanDate?: string;
  appVersion: string;
}

// ── Navigation Types ───────────────────────────────────────────────────────
export type RootStackParamList = {
  Onboarding: undefined;
  Home: undefined;
  Sort: undefined;
  Pie: undefined;
  SliceDetail: { bucketKey: BucketKey };
  ManualAdd: undefined;
  History: { filter?: BucketKey };
  Profile: undefined;
  Settings: undefined;
};
