/**
 * Spend-na Theme — Colors
 * ─────────────────────────────────────────────────────────────
 * All colors used across the app defined in one place.
 * Change here → changes everywhere. Easy brand updates.
 * ─────────────────────────────────────────────────────────────
 * Author: Sandeep | Spend-na v1.0
 */

export const Colors = {
  // ── Bucket Colors ─────────────────────────────────────────
  necessary: '#10b981',      // Green  — food, medicine, rent
  comfortable: '#f59e0b',    // Amber  — lifestyle, comfort
  luxury: '#f43f5e',         // Red    — splurge, wants

  // ── Brand Colors ──────────────────────────────────────────
  brand: '#22d3ee',          // Spend-na cyan from logo
  brandDeep: '#6366f1',      // Spend-na indigo
  brandGradient: ['#22d3ee', '#6366f1'],

  // ── Background ────────────────────────────────────────────
  background: '#f8faff',     // Soft white-blue
  backgroundDark: '#0f172a', // Deep navy for home screen
  card: '#ffffff',           // Pure white cards
  cardDark: '#1e293b',       // Dark cards

  // ── Text ──────────────────────────────────────────────────
  textPrimary: '#1a1a2e',    // Near black
  textSecondary: '#64748b',  // Medium grey
  textMuted: '#94a3b8',      // Light grey
  textWhite: '#ffffff',      // Pure white
  textOnDark: '#f1f5f9',     // Off white on dark bg

  // ── UI Elements ───────────────────────────────────────────
  border: '#e2e8f0',         // Subtle borders
  borderDark: '#334155',     // Dark mode borders
  divider: '#f1f5f9',        // Section dividers
  shadow: 'rgba(0,0,0,0.08)',// Card shadows

  // ── Status Colors ─────────────────────────────────────────
  success: '#16a34a',        // Confirmation green
  warning: '#d97706',        // Caution amber
  error: '#dc2626',          // Error red
  info: '#0284c7',           // Info blue

  // ── Bucket Background Tints (10% opacity) ─────────────────
  necessaryBg: '#d1fae5',
  comfortableBg: '#fef3c7',
  luxuryBg: '#ffe4e6',

  // ── Transparent overlays ──────────────────────────────────
  overlay: 'rgba(0,0,0,0.5)',
  overlayLight: 'rgba(255,255,255,0.1)',
};

// Bucket config — single source of truth for all bucket data
export const BucketConfig = {
  necessary: {
    key: 'necessary',
    label: 'Necessary',
    shortLabel: 'Need',
    icon: '🏠',
    color: Colors.necessary,
    bgColor: Colors.necessaryBg,
    description: 'Food, medicine, rent, education',
    value: 0,
  },
  comfortable: {
    key: 'comfortable',
    label: 'Comfortable',
    shortLabel: 'Okay',
    icon: '😊',
    color: Colors.comfortable,
    bgColor: Colors.comfortableBg,
    description: 'Lifestyle, transport, shopping',
    value: 1,
  },
  luxury: {
    key: 'luxury',
    label: 'Luxury',
    shortLabel: 'Luxury',
    icon: '👑',
    color: Colors.luxury,
    bgColor: Colors.luxuryBg,
    description: 'Splurge, wants, high-end',
    value: 2,
  },
};
