/**
 * Spend-na Theme — Typography & Spacing
 * ─────────────────────────────────────────────────────────────
 * All font sizes, weights and spacing in one place.
 * Follows 8pt grid system for consistent layouts.
 * ─────────────────────────────────────────────────────────────
 */

import { Platform } from 'react-native';

export const Typography = {
  // Font families
  fontFamily: {
    regular: Platform.OS === 'ios' ? 'SF Pro Text' : 'Roboto',
    medium: Platform.OS === 'ios' ? 'SF Pro Text' : 'Roboto-Medium',
    bold: Platform.OS === 'ios' ? 'SF Pro Text' : 'Roboto-Bold',
    mono: Platform.OS === 'ios' ? 'SF Mono' : 'monospace',
  },

  // Font sizes — T-shirt sizing
  fontSize: {
    xs: 10,
    sm: 12,
    base: 14,
    md: 16,
    lg: 18,
    xl: 20,
    xxl: 24,
    xxxl: 32,
    display: 40,
    hero: 56,
  },

  // Font weights
  fontWeight: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
    extrabold: '800' as const,
  },

  // Line heights
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.7,
  },

  // Letter spacing
  letterSpacing: {
    tight: -0.5,
    normal: 0,
    wide: 0.5,
    wider: 1,
    widest: 2,
  },
};

export const Spacing = {
  // Base spacing unit = 4px
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 48,
  huge: 64,

  // Screen padding
  screenPadding: 16,
  screenPaddingLarge: 24,

  // Card padding
  cardPadding: 16,
  cardPaddingSmall: 12,

  // Border radius
  radius: {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
    round: 999,
  },
};
