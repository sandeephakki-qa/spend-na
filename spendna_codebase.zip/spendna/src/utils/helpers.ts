/**
 * Spend-na — Utility Helpers
 * ─────────────────────────────────────────────────────────────
 * Common utility functions used across the app.
 * Pure functions — no side effects. Easy to test.
 * ─────────────────────────────────────────────────────────────
 */

/**
 * Generate a unique ID for expenses
 * Uses timestamp + random string — no external library needed
 */
export const generateId = (): string => {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substr(2, 9);
  return `${timestamp}_${random}`;
};

/**
 * Format amount in Indian number system
 * 1000 → ₹1,000 | 100000 → ₹1,00,000
 */
export const formatAmount = (amount: number): string => {
  return `₹${amount.toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
};

/**
 * Format amount in compact form for small spaces
 * 1500 → ₹1.5k | 150000 → ₹1.5L
 */
export const formatAmountCompact = (amount: number): string => {
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(1)}L`;
  if (amount >= 1000) return `₹${(amount / 1000).toFixed(1)}k`;
  return `₹${amount}`;
};

/**
 * Get month name from month number
 * 1 → January | 12 → December
 */
export const getMonthName = (month: number): string => {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];
  return months[month - 1] || '';
};

/**
 * Get short month name
 * 1 → Jan | 12 → Dec
 */
export const getShortMonthName = (month: number): string => {
  return getMonthName(month).slice(0, 3);
};

/**
 * Check if app is in learning phase
 * First 3 months — no nudges shown
 * @param createdAt User account creation date ISO string
 */
export const isInLearningPhase = (createdAt: string): boolean => {
  const created = new Date(createdAt);
  const threeMonthsLater = new Date(created);
  threeMonthsLater.setMonth(threeMonthsLater.getMonth() + 3);
  return new Date() < threeMonthsLater;
};

/**
 * Calculate percentage safely — avoids division by zero
 */
export const calculatePercentage = (part: number, total: number): number => {
  if (total === 0) return 0;
  return Math.round((part / total) * 100);
};
