# 🐦 Spend-na

> *Making digital money visible. One tap at a time.*

Spend-na is a personal money awareness app built for the generation that grew up with UPI, cards and contactless payments. Digital money feels like air — invisible, effortless, gone before you notice. Spend-na gives it back its weight.

---

## 💡 The Philosophy

- **Your data. Your phone. Only.** Nothing leaves your device.
- **No guilt. Ever.** Awareness not judgment.
- **You classify.** The app never assumes.
- **First 3 months** — just learn. No nudges.
- **One warm question** — not a lecture. Never.

---

## 🪣 The Three Buckets

| Bucket | Colour | Examples |
|--------|--------|---------|
| 🏠 Necessary | Green | Food, medicine, rent, education |
| 😊 Comfortable | Amber | Transport, lifestyle, shopping |
| 👑 Luxury | Red | Splurge, wants, high-end |

---

## 📱 Platform Support

- Android (React Native) — SMS reading supported
- iOS (React Native) — Manual entry + future TestFlight
- Tablet ready — iPad Mini, Android tablets

---

## 🗂️ Project Structure

```
spendna/
├── src/
│   ├── screens/          # All app screens
│   │   ├── HomeScreen    # Wallet moment — warm greeting
│   │   ├── SortScreen    # Classify transactions
│   │   ├── PieScreen     # Visual spending picture
│   │   ├── SliceDetail   # Bucket deep dive
│   │   └── ManualAdd     # Add cash/loan/other spends
│   ├── services/         # Core business logic
│   │   ├── StorageService   # Local only — AsyncStorage
│   │   ├── SMSService       # Android SMS reading
│   │   └── NotificationService  # Morning/evening nudges
│   ├── theme/            # Design system
│   │   ├── colors.ts     # All colors in one place
│   │   └── typography.ts # Fonts and spacing
│   ├── types/            # TypeScript models
│   │   └── index.ts      # All interfaces and types
│   └── utils/            # Helper functions
│       └── helpers.ts    # Pure utility functions
├── android/              # Android native project
├── ios/                  # iOS native project
└── __tests__/            # All tests
```

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- Java JDK 17
- Android Studio (for Android)
- Xcode 15+ on macOS (for iOS)

### Installation

```bash
# Clone the repository
git clone https://github.com/sandeephakki/spendna.git
cd spendna

# Install dependencies
npm install

# iOS only — install pods
cd ios && pod install && cd ..
```

### Running

```bash
# Start Metro bundler
npm start

# Run on Android
npm run android

# Run on iOS
npm run ios
```

---

## 🔒 Privacy First

Spend-na is built on a trust-first architecture:

1. SMS is **never** read silently in background
2. User sees count of messages **before** approving scan
3. All data stored in device local storage only
4. No analytics, no tracking, no ads
5. No server. No cloud. No accounts required.

---

## 🗺️ Roadmap

- [x] Phase 1 — Core app (Home, Sort, Pie, Manual Add)
- [ ] Phase 2 — AI suggestions after 3 months learning
- [ ] Phase 3 — Multi-device sync via email ID
- [ ] Phase 4 — Bank feed integration
- [ ] Phase 5 — App Store + Play Store launch

---

## 👨‍💻 Author

Built with ❤️ by Sandeep
*Inspired by the feel of a physical wallet*

---

*"Every rupee has a story. Make yours count."*
