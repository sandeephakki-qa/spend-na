@echo off
echo.
echo  ==========================================
echo   Spend-na — Push to GitHub
echo  ==========================================
echo.

REM Navigate to project folder — update this path
cd /d "%~dp0"

REM Initialize git if not already done
if not exist ".git" (
    echo Initializing git repository...
    git init
    echo Git initialized.
)

REM Add GitHub remote — replace with your repo URL
echo Adding GitHub remote...
git remote remove origin 2>nul
git remote add origin https://github.com/sandeephakki/spendna.git

REM Stage all files
echo Staging all files...
git add .

REM Commit with timestamp
set TIMESTAMP=%date% %time%
git commit -m "Spend-na: Initial commit — %TIMESTAMP%"

REM Push to GitHub
echo Pushing to GitHub...
git branch -M main
git push -u origin main

echo.
echo  ==========================================
echo   Done! Check github.com/sandeephakki/spendna
echo  ==========================================
echo.
pause
